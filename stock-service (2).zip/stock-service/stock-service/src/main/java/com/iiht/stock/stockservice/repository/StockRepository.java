package com.iiht.stock.stockservice.repository;

import com.iiht.stock.stockservice.entity.Stock;

import java.util.Date;
import java.util.List;

public interface StockRepository {
    public boolean addStockPrice(int companyCode, Stock stock);
    public List<Stock> getStockPriceListByDate(int companyCode, Date startDate, Date endDate);
}
