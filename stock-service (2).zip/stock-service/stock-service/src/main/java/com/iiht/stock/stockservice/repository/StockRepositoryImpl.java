package com.iiht.stock.stockservice.repository;

import com.iiht.stock.stockservice.entity.Stock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Repository
public class StockRepositoryImpl implements StockRepository {
    private static final Logger logger = LoggerFactory.getLogger(StockRepositoryImpl.class);

    @Override
    public boolean addStockPrice(int companyCode, Stock stock) {
        logger.info("Inside repository: add stock price for company");
        boolean i = false;
        Date date = Date.valueOf(LocalDate.now());
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stock", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("insert into stock_price(stock_id,company_code, stock_price, created_date) values(?,?,?,?)");
            Random r=new Random();
            int no=r.nextInt(9000)+1000;
            ps.setInt(1, no);
            ps.setInt(2, companyCode);
            ps.setDouble(3, stock.getStockPrice());
            ps.setDate(4, date);

            i = ps.execute();
            //System.out.println(i); //returns false
            ps.close();
            conn.close();
            if (i == false)
                return true;
            else
                return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Stock> getStockPriceListByDate(int companyCode, java.util.Date startDate, java.util.Date endDate) {
        List<Stock> stockList = new ArrayList<>();
        try {
            logger.info("Inside repository: getStockPriceListByDate companyCode: {}, startDate : {}, endDate: {}",companyCode, startDate, endDate);
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/stock", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("select * from stock_price where company_code = ? and created_date between ? and ?");
            java.sql.Date sqlStartDate
                    = new java.sql.Date(startDate.getTime());
            ps.setInt(1, companyCode);
            ps.setDate(2, sqlStartDate);
            ps.setDate(3, new java.sql.Date(endDate.getTime()));
            ResultSet rs = ps.executeQuery();
            Stock stock = null;
            while (rs.next()) {
                stock = new Stock();
                int stockId = rs.getInt("stock_id");
                stock.setStockId(stockId);

                int companyId = rs.getInt("company_code");
                stock.setCompanyCode(companyId);

                Double stockPrice = rs.getDouble("stock_price");
                stock.setStockPrice(stockPrice);

                Date createdDate = rs.getDate("created_date");
                stock.setCreatedDate(createdDate);

                stockList.add(stock);

            }
        } catch (SQLException e) {
            System.out.println(e);
            //throw e;
        }
        logger.info("getStockPriceListByDate: {}", stockList);
        return stockList;
    }
}
