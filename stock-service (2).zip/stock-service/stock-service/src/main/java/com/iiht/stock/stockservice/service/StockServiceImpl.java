package com.iiht.stock.stockservice.service;

import com.iiht.stock.stockservice.entity.Stock;
import com.iiht.stock.stockservice.repository.StockRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class StockServiceImpl implements StockService{
    private static final Logger logger = LoggerFactory.getLogger(StockServiceImpl.class);

    @Autowired
    private StockRepository stockRepository;

    @Override
    public boolean addStockPrice(int companyCode, Stock stock){
        return stockRepository.addStockPrice(companyCode, stock);
    }

    @Override
    public List<Stock> getStockPriceListByDate(int companyCode, Date startDate, Date endDate) {
        return stockRepository.getStockPriceListByDate(companyCode, startDate, endDate);
    }
}
