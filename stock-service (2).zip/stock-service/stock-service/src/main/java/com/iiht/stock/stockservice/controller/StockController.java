package com.iiht.stock.stockservice.controller;

import com.iiht.stock.stockservice.entity.Stock;
import com.iiht.stock.stockservice.service.StockService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {
    private static final Logger logger = LoggerFactory.getLogger(StockController.class);

    @Autowired
    private StockService stockservice;

    @PostMapping("/add/{companyCode}")
    @ApiOperation(value="Add stock price for company")
    public String addStockPriceForCompany(@PathVariable int companyCode, @RequestBody Stock request){
        logger.info("StockService: addStockPriceForCompany request: {}", request);
        boolean value = stockservice.addStockPrice(companyCode,request);
        if(value == true) {
            logger.info("StockService: addStockPriceForCompany response: success");
            return "stock price added for company code successfully";
        }
        else {
            logger.info("StockService: addStockPriceForCompany response: error");
            return "Error in adding stock price";
        }
    }

    @GetMapping("/get/{companyCde}/{startDate}/{endDate}")
    public List<Stock> getStockPriceListByDate(@PathVariable int companyCde,
                                               @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                               @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate){

        List<Stock> stockList =  stockservice.getStockPriceListByDate(companyCde, startDate, endDate);
        logger.info("StockService: getStockPriceListByDate response: {}", stockList);
        return stockList;
    }
}
