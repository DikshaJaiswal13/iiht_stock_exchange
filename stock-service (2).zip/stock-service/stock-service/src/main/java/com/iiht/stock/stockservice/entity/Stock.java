package com.iiht.stock.stockservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name="stock_price")
public class Stock {

    @Id
    @Column(name="stock_id")
    @NotNull
    private int stockId;

    @Column(name="company_code")
    @NotNull
    private int companyCode;

    @Column(name="stock_price")
    @NotNull
    private double stockPrice;

    @Column(name="created_date")
    @NotNull
    private Date createdDate;

    public int getStockId() {
        return stockId;
    }

    public void setStockId(int stockId) {
        this.stockId = stockId;
    }

    public int getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(int companyCode) {
        this.companyCode = companyCode;
    }

    public double getStockPrice() {
        return stockPrice;
    }

    public void setStockPrice(double stockPrice) {
        this.stockPrice = stockPrice;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @Override
    public String toString() {
        return "Stock{" +
                "stockId=" + stockId +
                ", companyCode=" + companyCode +
                ", stockPrice=" + stockPrice +
                ", createdDate=" + createdDate +
                '}';
    }
}
