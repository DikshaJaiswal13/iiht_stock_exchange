package com.iiht.stock.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaServer
public class StockGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockGatewayApplication.class, args);
	}

}
