package com.iiht.stock.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
