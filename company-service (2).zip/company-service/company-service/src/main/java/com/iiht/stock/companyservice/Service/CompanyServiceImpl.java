package com.iiht.stock.companyservice.Service;

import com.iiht.stock.companyservice.Entity.Company;
import com.iiht.stock.companyservice.Repository.CompanyRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImpl implements CompanyService{

    private static final Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class);

    @Autowired
    private CompanyRepository companyRepository;
    @Override
    public boolean registerCompany(Company company) {
        logger.info("Inside service: register company");
        return companyRepository.registerCompany(company);
    }

    @Override
    public Company getCompanyByCompanyCode(int companyCode) {
        Company company = companyRepository.getCompanyByCompanyCode(companyCode);
        return company;
    }

    @Override
    public List<Company> getCompanyList() {
        List<Company> companyList = companyRepository.getCompanyList();
        return companyList;
    }

    @Override
    public boolean deleteCompanyByCompanyCode(int companyCode) {
        return companyRepository.deleteCompanyByCompanyCode(companyCode);
    }
}
