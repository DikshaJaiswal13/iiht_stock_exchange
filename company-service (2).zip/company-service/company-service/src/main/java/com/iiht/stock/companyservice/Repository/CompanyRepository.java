package com.iiht.stock.companyservice.Repository;

import com.iiht.stock.companyservice.Entity.Company;

import java.util.List;

public interface CompanyRepository {
    public boolean registerCompany(Company company);
    public Company getCompanyByCompanyCode(int companyCode);
    public List<Company> getCompanyList();
    public boolean deleteCompanyByCompanyCode(int companyCode);
}
