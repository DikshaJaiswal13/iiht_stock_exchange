package com.iiht.stock.companyservice.Repository;

import com.iiht.stock.companyservice.Entity.Company;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Repository
public class CompanyRepositoryImpl implements CompanyRepository {
    private static final Logger logger = LoggerFactory.getLogger(CompanyRepositoryImpl.class);
    @Override
    public boolean registerCompany(Company company) {
        logger.info("Inside repository: register company");
        boolean i = false;
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("insert into company(company_code,company_name, company_ceo, company_turnover, company_website, stock_exchange) values(?,?,?,?,?,?)");
            Random r=new Random();
            int no=r.nextInt(9000)+1000;
            ps.setInt(1, no);
            ps.setString(2, company.getCompanyName());
            ps.setString(3, company.getCompanyCeo());
            ps.setDouble(4, company.getCompanyTurnover());
            ps.setString(5, company.getCompanyWebsite());
            ps.setString(6, company.getStockExchange());

            i = ps.execute();
            //System.out.println(i); //returns false
            ps.close();
            conn.close();
            if (i == false)
                return true;
            else
                return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Company getCompanyByCompanyCode(int companyCode) {
        Company company = null;
        try {
            logger.info("Inside repository: getCompanyByCompanyCode : {}",companyCode);
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/diksha", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("select * from company where company_code = ?");
            ps.setInt(1, companyCode);
            ResultSet rs = ps.executeQuery();
            //Company company = null;
            while (rs.next()) {
                company = new Company();
                int companyId = rs.getInt("company_code");
                company.setCompanyCode(companyId);

                String companyName = rs.getString("company_name");
                company.setCompanyName(companyName);

                String companyCeo = rs.getString("company_ceo");
                company.setCompanyCeo(companyCeo);

                company.setCompanyTurnover(rs.getDouble("company_turnover"));

                company.setCompanyWebsite(rs.getString("company_website"));

                //Sector sector=new Sector();
                company.setStockExchange(rs.getString("stock_exchange"));
                logger.info("companyByCompanyCode: {}", company);
                //return company;
            }
        } catch (SQLException e) {
            System.out.println(e);
            //throw e;
        }
        return company;
    }

    @Override
    public List<Company> getCompanyList() {
        List<Company> companyList = new ArrayList<Company>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/diksha", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("select * from company");
            ResultSet rs = ps.executeQuery();
            Company company = null;
            while (rs.next()) {
                company = new Company();
                int companyId = rs.getInt("company_code");
                company.setCompanyCode(companyId);

                String companyName = rs.getString("company_name");
                company.setCompanyName(companyName);

                String companyCeo = rs.getString("company_ceo");
                company.setCompanyCeo(companyCeo);

                company.setCompanyTurnover(rs.getDouble("company_turnover"));

                company.setCompanyWebsite(rs.getString("company_website"));

                //Sector sector=new Sector();
                company.setStockExchange(rs.getString("stock_exchange"));

                companyList.add(company);
            }
        } catch (SQLException e) {
            System.out.println(e);
            //throw e;
        }
        return companyList;
    }

    @Override
    public boolean deleteCompanyByCompanyCode(int companyCode) {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/diksha", "root", "pass@word1");
            PreparedStatement ps = conn.prepareStatement("delete from company where company_code = ?");
            ps.setInt(1, companyCode);
            boolean i = ps.execute();
            if (!i)
                return true;
            else
                return false;
        } catch (SQLException e) {
            System.out.println(e);
            //throw e;
        }
        return false;
    }
}

