package com.iiht.stock.companyservice.Entity;


import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="company")
public class Company {

    @Id
    @Column(name="company_code")
    @NotNull
    private int companyCode;

    @Column(name="company_name")
    @NotNull(message= "companyName should not be null")
    private String companyName;

    @Column(name="company_ceo")
    @NotNull
    private String companyCeo;

    @Column(name="company_turnover")
    @NotNull
    @Min(value= 10, message = "turnover should be greater than 10cr")
    private double companyTurnover;

    @Column(name="company_website")
    @NotNull
    private String companyWebsite;

    @Column(name="stock_exchange")
    @NotNull
    private String stockExchange;

    public int getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(int companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCeo() {
        return companyCeo;
    }

    public void setCompanyCeo(String companyCeo) {
        this.companyCeo = companyCeo;
    }

    public double getCompanyTurnover() {
        return companyTurnover;
    }

    public void setCompanyTurnover(double companyTurnover) {
        this.companyTurnover = companyTurnover;
    }

    public String getCompanyWebsite() {
        return companyWebsite;
    }

    public void setCompanyWebsite(String companyWebsite) {
        this.companyWebsite = companyWebsite;
    }

    public String getStockExchange() {
        return stockExchange;
    }

    public void setStockExchange(String stockExchange) {
        this.stockExchange = stockExchange;
    }

    @Override
    public String toString() {
        return "Company{" +
                "companyCode=" + companyCode +
                ", companyName='" + companyName + '\'' +
                ", companyCeo='" + companyCeo + '\'' +
                ", companyTurnover=" + companyTurnover +
                ", companyWebsite='" + companyWebsite + '\'' +
                ", stockExchange='" + stockExchange + '\'' +
                '}';
    }
}
