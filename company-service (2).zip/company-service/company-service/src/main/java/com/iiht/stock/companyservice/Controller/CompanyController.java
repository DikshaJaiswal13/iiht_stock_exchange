package com.iiht.stock.companyservice.Controller;

import com.iiht.stock.companyservice.Entity.Company;
import com.iiht.stock.companyservice.Service.CompanyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/market/company")
public class CompanyController {
    private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);

    @Autowired
    private CompanyService companyService;

    @PostMapping("/register")
    public String registerCompany(@RequestBody Company request){
        logger.info("CompanyService: registerCompany request: {}", request);
        boolean value = companyService.registerCompany(request);
        if(value == true) {
            logger.info("CompanyService: registerCompany response: company registered successfully");
            return "company registered successfully";
        }else {
            logger.info("CompanyService: registerCompany response: error in registering company");
            return "error in registering company";
        }
    }

    @GetMapping("/info/{companyCode}")
    public Company getCompanyByCompnyCode(@PathVariable int companyCode){
        Company company = companyService.getCompanyByCompanyCode(companyCode);
        if(company != null) {
            logger.info("CompanyService: getCompanyByCompnyCode response: {}", company);
            return company;
        }else{
            logger.info("CompanyService: getCompanyByCompnyCode response: null");
            return null;
        }
    }

    @GetMapping("/info/getAll")
    public List<Company> getCompanyList(){
        List<Company> companyList = companyService.getCompanyList();
        if(companyList != null) {
            logger.info("CompanyService: getCompanyList response: {}", companyList);
            return companyList;
        }else {
            logger.info("CompanyService: getCompanyList response: null");
            return null;
        }
    }

    @DeleteMapping("/delete/{companyCode}")
    public String deleteCompanyByCompanyCode(@PathVariable int companyCode){
        boolean company = companyService.deleteCompanyByCompanyCode(companyCode);
        if(company == true) {
            logger.info("CompanyService: deleteCompanyByCompanyCode response:  company deleted successfully");
            return "company deleted successfully";
        }else {
            logger.info("CompanyService: deleteCompanyByCompanyCode response: Error in deleting company");
            return "Error in deleting company";
        }
    }

}
